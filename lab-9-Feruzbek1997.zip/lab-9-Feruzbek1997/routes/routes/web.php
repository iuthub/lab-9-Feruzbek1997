<?php

/*
routes/web.php file!
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/blog', function () {
    return view('blog.index');
});

Route::get('/post/{id}', function ($id) {
    //return "Post with ID: ".$id;
    return view('blog.post');
}); //post/1

Route::get('/admin', function () {
    return view('admin.index');
})->name('admin.index');

Route::get('/admin/create', function () {
    return view('admin.create');
})->name('admin.create'); 

Route::get('/admin/edit/{id}', function ($id) {
    //return "Edit post with ID: ".$id;
    return view('admin.edit');
})->name('admin.edit');

Route::get('/about', function () {
    return view('other.about');
})->name('other.about');


Route::post ('create', function ( \Illuminate\Http\Request $request ,
									\Illuminate\Validation\Factory $validator ) {
	$validation = $validator -> make ( $request -> all(), [
		'title' => 'required|min:5',
		'content' => 'required|min:10'
	]);
	if ($validation -> fails()) {
		return redirect()->back()->withErrors($validation);
	}
	return redirect()
	->route('admin.index')
	->with('info', 'Post created , Title : ' . $request -> input('title'));
})-> name('admin.create');