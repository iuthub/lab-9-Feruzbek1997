@extends('layouts.master')

@section('content')
<div class="row">
        <div class="col-md-12">
            <p class="quote">Post</p>
        </div>
    </div>
@endsection